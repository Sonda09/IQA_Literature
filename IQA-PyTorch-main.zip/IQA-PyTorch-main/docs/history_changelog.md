# History of Changelog

- **March 5, 2022**. Add NRQM, PI, ILNIQE metrics.
- **Feb 2, 2022**. Add MUSIQ inference code, and the converted official weights. See [Official codes](https://github.com/google-research/google-research/tree/master/musiq).
